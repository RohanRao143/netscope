import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/providers/network_provider.dart';
import '../core/services/platform_network_service.dart';
import '../widgets/app_scaffold.dart';

class SettingsScreen extends StatefulWidget { const SettingsScreen({super.key}); @override State<SettingsScreen> createState()=>_SettingsScreenState(); }
class _SettingsScreenState extends State<SettingsScreen>{bool packet=false;@override void initState(){super.initState();PlatformNetworkService.isPacketInspectionActive().then((v){if(mounted)setState(()=>packet=v);});}
@override Widget build(BuildContext context)=>Consumer<NetworkProvider>(builder:(context,p,_)=>AppScaffold(title:'Settings',body:ListView(padding:const EdgeInsets.fromLTRB(16,16,16,100),children:[
Card(child:SwitchListTile(title:const Text('Live monitoring'),subtitle:Text(p.monitoring?'Network statistics are being monitored.':'Monitoring is stopped.'),value:p.monitoring,onChanged:p.usageAccess?(v)async{if(v){await p.startMonitoring();}else{await p.stopMonitoring();}}:null)),
Card(child:SwitchListTile(title:const Text('Start monitoring after reboot'),subtitle:const Text('Restarts network statistics monitoring after device boot.'),value:p.autoStart,onChanged:(v)=>p.setAutoStart(v))),
Card(child:SwitchListTile(title:const Text('DNS / packet inspection'),subtitle:const Text('Requires Android VPN consent. Captures DNS packet metadata only; payload contents are not decrypted.'),value:packet,onChanged:(v)async{if(v){await p.startPacketInspection();}else{await p.stopPacketInspection();}if(mounted)setState(()=>packet=v);},)),
Card(child:Column(children:[ListTile(leading:const Icon(Icons.security),title:const Text('Usage access'),subtitle:Text(p.usageAccess?'Permission granted':'Permission required'),trailing:const Icon(Icons.chevron_right),onTap:p.openUsageSettings),const Divider(height:1),ListTile(leading:const Icon(Icons.refresh),title:const Text('Refresh statistics'),onTap:()async{await p.refresh();await p.loadAnalytics();await p.loadHostStats();})])),const SizedBox(height:12),const Card(child:ListTile(leading:Icon(Icons.info_outline),title:Text('NetScope'),subtitle:Text('Local network usage monitor'))]));}
}
