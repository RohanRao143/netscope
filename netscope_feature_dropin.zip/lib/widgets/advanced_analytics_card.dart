import 'package:flutter/material.dart';
import '../core/models/network_analytics.dart';
import '../core/services/format_service.dart';
import 'analytics_charts.dart';

class AdvancedAnalyticsCard extends StatelessWidget {
 final NetworkAnalytics? analytics; final List<Map<String,dynamic>> hosts;
 const AdvancedAnalyticsCard({super.key,required this.analytics,required this.hosts});
 @override Widget build(BuildContext context){final a=analytics;return Column(children:[if(a!=null)Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Advanced network analytics',style:Theme.of(context).textTheme.titleLarge),const SizedBox(height:12),UsageSplitChart(wifi:a.wifiBytes,mobile:a.mobileBytes,foreground:a.foregroundBytes,background:a.backgroundBytes)]))),const SizedBox(height:12),_HostsCard(hosts:hosts)]);}
}
class _HostsCard extends StatefulWidget{final List<Map<String,dynamic>> hosts;const _HostsCard({required this.hosts});@override State<_HostsCard> createState()=>_HostsCardState();}
class _HostsCardState extends State<_HostsCard>{bool expanded=false;@override Widget build(BuildContext context){final list=widget.hosts.take(expanded?10:3).toList();return Card(child:ExpansionTile(initiallyExpanded:expanded,onExpansionChanged:(v)=>setState(()=>expanded=v),title:const Text('Top network hosts'),subtitle:Text(widget.hosts.isEmpty?'Enable packet/DNS inspection to collect host frequency.':'Based on observed DNS frequency'),children:list.isEmpty?[const ListTile(title:Text('No host data captured yet.'))]:list.asMap().entries.map((e){final m=e.value;return ListTile(leading:CircleAvatar(child:Text('${e.key+1}')),title:Text(m['host']?.toString()??'Unknown host'),trailing:Text('${(m['count'] as num?)?.toInt()??0} requests'));}).toList());}}
